import { db } from "./db";
import { products } from "@shared/schema";

const productData = [
  {
    name: "Signature Leather Handbag",
    price: "2499.00",
    imageUrl: "/attached_assets/generated_images/Luxury_handbag_product_5cc5907a.png",
    category: "Accessories",
    description: "Handcrafted from premium Italian leather, this signature handbag combines timeless elegance with modern functionality.",
    inStock: true,
  },
  {
    name: "Gold Jewelry Collection",
    price: "3799.00",
    imageUrl: "/attached_assets/generated_images/Gold_jewelry_collection_caec341b.png",
    category: "Jewelry",
    description: "Exquisite 18k gold jewelry set featuring intricate craftsmanship and ethically sourced materials.",
    inStock: true,
  },
  {
    name: "Designer Sunglasses",
    price: "899.00",
    imageUrl: "/attached_assets/generated_images/Designer_sunglasses_product_120ebff3.png",
    category: "Eyewear",
    description: "Luxury sunglasses with polarized lenses and titanium frames, offering superior UV protection and style.",
    inStock: true,
  },
  {
    name: "Premium Leather Wallet",
    price: "599.00",
    imageUrl: "/attached_assets/generated_images/Luxury_handbag_product_5cc5907a.png",
    category: "Accessories",
    description: "Slim bifold wallet crafted from full-grain leather with RFID protection and precision stitching.",
    inStock: true,
  },
  {
    name: "Diamond Bracelet",
    price: "5299.00",
    imageUrl: "/attached_assets/generated_images/Gold_jewelry_collection_caec341b.png",
    category: "Jewelry",
    description: "Stunning tennis bracelet featuring conflict-free diamonds in a platinum setting.",
    inStock: true,
  },
  {
    name: "Aviator Sunglasses",
    price: "799.00",
    imageUrl: "/attached_assets/generated_images/Designer_sunglasses_product_120ebff3.png",
    category: "Eyewear",
    description: "Classic aviator design with modern materials and advanced lens technology for optimal clarity.",
    inStock: true,
  },
];

async function seed() {
  console.log("Seeding database...");
  
  try {
    const existingProducts = await db.select().from(products);
    
    if (existingProducts.length > 0) {
      console.log("Products already exist, skipping seed");
      return;
    }

    await db.insert(products).values(productData);
    console.log("Successfully seeded products!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

seed().then(() => process.exit(0)).catch(() => process.exit(1));
