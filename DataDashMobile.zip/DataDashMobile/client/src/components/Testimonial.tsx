import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Quote } from "lucide-react";

interface TestimonialProps {
  quote: string;
  author: string;
  role: string;
  imageUrl?: string;
}

export default function Testimonial({ quote, author, role, imageUrl }: TestimonialProps) {
  return (
    <Card className="p-8 space-y-6">
      <Quote className="h-10 w-10 text-primary/30" />
      <p className="text-lg leading-relaxed italic text-foreground" data-testid="text-testimonial-quote">
        "{quote}"
      </p>
      <div className="flex items-center gap-4">
        <Avatar className="h-12 w-12">
          {imageUrl && <AvatarImage src={imageUrl} alt={author} />}
          <AvatarFallback>{author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-semibold" data-testid="text-testimonial-author">{author}</p>
          <p className="text-sm text-muted-foreground" data-testid="text-testimonial-role">{role}</p>
        </div>
      </div>
    </Card>
  );
}
