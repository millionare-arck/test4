import { Shield, Truck, Award } from "lucide-react";

const features = [
  {
    icon: Truck,
    title: "Premium Delivery",
    description: "Complimentary worldwide shipping on all orders with white-glove service"
  },
  {
    icon: Shield,
    title: "Authenticity Guaranteed",
    description: "Every piece is authenticated and comes with a certificate of authenticity"
  },
  {
    icon: Award,
    title: "Concierge Service",
    description: "Dedicated personal shopping assistance for a bespoke experience"
  }
];

export default function ValueProposition() {
  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div 
                key={index} 
                className="text-center space-y-4"
                data-testid={`feature-${index}`}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary">
                  <Icon className="h-8 w-8" />
                </div>
                <h3 className="font-serif text-xl font-medium" data-testid={`text-feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed" data-testid={`text-feature-description-${index}`}>
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
