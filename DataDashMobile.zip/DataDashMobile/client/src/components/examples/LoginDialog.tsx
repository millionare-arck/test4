import { useState } from "react";
import LoginDialog from '../LoginDialog';
import { Button } from "@/components/ui/button";

export default function LoginDialogExample() {
  const [open, setOpen] = useState(false);
  
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open Login Dialog</Button>
      <LoginDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
