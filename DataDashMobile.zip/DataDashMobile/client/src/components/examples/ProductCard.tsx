import ProductCard from '../ProductCard';
import productImage from '@assets/generated_images/Luxury_handbag_product_5cc5907a.png';

export default function ProductCardExample() {
  return (
    <div className="max-w-sm">
      <ProductCard
        id="1"
        name="Signature Leather Handbag"
        price={2499}
        imageUrl={productImage}
        category="Accessories"
      />
    </div>
  );
}
