import ContactForm from '../ContactForm';

export default function ContactFormExample() {
  return (
    <div className="max-w-2xl">
      <ContactForm />
    </div>
  );
}
