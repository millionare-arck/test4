import Hero from '../Hero';
import heroImage from '@assets/generated_images/Luxury_hero_watch_image_ef817f30.png';

export default function HeroExample() {
  return (
    <Hero
      title="Timeless Elegance"
      subtitle="Discover our curated collection of premium luxury goods"
      imageUrl={heroImage}
    />
  );
}
