import ProductGrid from '../ProductGrid';
import handbagImage from '@assets/generated_images/Luxury_handbag_product_5cc5907a.png';
import jewelryImage from '@assets/generated_images/Gold_jewelry_collection_caec341b.png';
import sunglassesImage from '@assets/generated_images/Designer_sunglasses_product_120ebff3.png';

//todo: remove mock functionality
const mockProducts = [
  {
    id: "1",
    name: "Signature Leather Handbag",
    price: 2499,
    imageUrl: handbagImage,
    category: "Accessories"
  },
  {
    id: "2",
    name: "Gold Jewelry Collection",
    price: 3799,
    imageUrl: jewelryImage,
    category: "Jewelry"
  },
  {
    id: "3",
    name: "Designer Sunglasses",
    price: 899,
    imageUrl: sunglassesImage,
    category: "Eyewear"
  }
];

export default function ProductGridExample() {
  return <ProductGrid products={mockProducts} title="Featured Collection" />;
}
