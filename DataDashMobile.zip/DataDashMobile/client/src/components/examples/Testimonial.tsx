import Testimonial from '../Testimonial';
import testimonialImage from '@assets/generated_images/Customer_testimonial_portrait_e2c7be2d.png';

export default function TestimonialExample() {
  return (
    <div className="max-w-2xl">
      <Testimonial
        quote="The craftsmanship and attention to detail is simply unparalleled. Every piece tells a story of elegance and refinement."
        author="Sophia Martinez"
        role="Fashion Director"
        imageUrl={testimonialImage}
      />
    </div>
  );
}
