import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Eye } from "lucide-react";

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  imageUrl: string;
  category?: string;
}

export default function ProductCard({ id, name, price, imageUrl, category }: ProductCardProps) {
  return (
    <Card className="group overflow-hidden hover-elevate active-elevate-2 cursor-pointer" data-testid={`card-product-${id}`}>
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img 
          src={imageUrl} 
          alt={name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
        
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button 
            size="icon" 
            variant="secondary"
            className="bg-background/90 backdrop-blur-sm"
            onClick={() => console.log(`View product ${id}`)}
            data-testid={`button-view-${id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
        
        {category && (
          <div className="absolute top-4 left-4">
            <span className="bg-background/90 backdrop-blur-sm text-foreground text-xs px-3 py-1 rounded-full uppercase tracking-wider font-medium">
              {category}
            </span>
          </div>
        )}
      </div>
      
      <div className="p-6 space-y-4">
        <div>
          <h3 className="font-serif text-xl font-medium mb-1" data-testid={`text-product-name-${id}`}>
            {name}
          </h3>
          <p className="text-2xl font-semibold text-primary" data-testid={`text-product-price-${id}`}>
            ${price.toLocaleString()}
          </p>
        </div>
        
        <Button 
          className="w-full"
          onClick={() => console.log(`Add product ${id} to cart`)}
          data-testid={`button-add-to-cart-${id}`}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          Add to Cart
        </Button>
      </div>
    </Card>
  );
}
