import { useState } from "react";
import { Link } from "wouter";
import { ShoppingCart, Menu, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartItemCount] = useState(0); //todo: remove mock functionality

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2 hover-elevate active-elevate-2 px-3 py-2 rounded-md">
            <span className="font-serif text-2xl font-semibold tracking-tight">LuxeVault</span>
          </Link>

          <div className="hidden md:flex items-center space-x-1">
            <Link href="/">
              <Button variant="ghost" size="default" data-testid="link-home">Home</Button>
            </Link>
            <Link href="/products">
              <Button variant="ghost" size="default" data-testid="link-products">Collections</Button>
            </Link>
            <Link href="/about">
              <Button variant="ghost" size="default" data-testid="link-about">About</Button>
            </Link>
            <Link href="/contact">
              <Button variant="ghost" size="default" data-testid="link-contact">Contact</Button>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-2">
            <ThemeToggle />
            <Link href="/account">
              <Button variant="ghost" size="icon" data-testid="button-account">
                <User className="h-5 w-5" />
              </Button>
            </Link>
            <Button variant="ghost" size="icon" className="relative" data-testid="button-cart">
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs font-medium rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </Button>
          </div>

          <div className="md:hidden flex items-center space-x-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="px-4 py-4 space-y-2">
            <Link href="/" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start" data-testid="link-mobile-home">
                Home
              </Button>
            </Link>
            <Link href="/products" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start" data-testid="link-mobile-products">
                Collections
              </Button>
            </Link>
            <Link href="/about" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start" data-testid="link-mobile-about">
                About
              </Button>
            </Link>
            <Link href="/contact" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start" data-testid="link-mobile-contact">
                Contact
              </Button>
            </Link>
            <div className="pt-4 border-t border-border flex gap-2">
              <Link href="/account" onClick={() => setMobileMenuOpen(false)} className="flex-1">
                <Button variant="outline" className="w-full" data-testid="button-mobile-account">
                  <User className="h-4 w-4 mr-2" />
                  Account
                </Button>
              </Link>
              <Button variant="outline" className="relative flex-1" data-testid="button-mobile-cart">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Cart
                {cartItemCount > 0 && (
                  <span className="ml-2 bg-primary text-primary-foreground text-xs font-medium rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
