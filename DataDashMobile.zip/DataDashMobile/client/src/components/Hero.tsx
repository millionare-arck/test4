import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface HeroProps {
  title: string;
  subtitle: string;
  imageUrl: string;
  ctaText?: string;
  ctaLink?: string;
}

export default function Hero({ title, subtitle, imageUrl, ctaText = "Shop Now", ctaLink = "/products" }: HeroProps) {
  return (
    <div className="relative h-[90vh] min-h-[600px] w-full overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src={imageUrl} 
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/60" />
      </div>
      
      <div className="relative h-full flex items-center justify-center px-4">
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="font-serif text-5xl md:text-7xl font-semibold text-white tracking-tight" data-testid="text-hero-title">
            {title}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-light max-w-2xl mx-auto" data-testid="text-hero-subtitle">
            {subtitle}
          </p>
          <div className="pt-4">
            <Button 
              size="lg" 
              className="bg-primary/90 backdrop-blur-sm hover:bg-primary text-primary-foreground border border-primary-border text-base uppercase tracking-wider"
              data-testid="button-hero-cta"
              onClick={() => console.log(`Navigate to ${ctaLink}`)}
            >
              {ctaText}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-white/50 rounded-full" />
        </div>
      </div>
    </div>
  );
}
