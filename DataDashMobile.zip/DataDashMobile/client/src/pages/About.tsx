import { Card } from "@/components/ui/card";
import workshopImage from '@assets/generated_images/Luxury_workshop_interior_5687894c.png';

export default function About() {
  return (
    <div className="min-h-screen">
      <div className="relative h-[60vh] min-h-[400px] w-full overflow-hidden">
        <img 
          src={workshopImage} 
          alt="Our Workshop"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/60" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="font-serif text-5xl md:text-7xl font-semibold text-white" data-testid="text-about-title">
            Our Story
          </h1>
        </div>
      </div>

      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="space-y-6">
            <h2 className="font-serif text-4xl font-semibold">Crafting Excellence Since 2010</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              LuxeVault was born from a passion for timeless elegance and exceptional craftsmanship. 
              We believe that luxury is not just about owning beautiful things, but about the stories 
              they tell and the moments they create.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Our curated collection represents the pinnacle of artisanal excellence, featuring pieces 
              from renowned designers and emerging talents who share our commitment to quality and innovation.
            </p>
          </div>

          <div className="space-y-6">
            <h2 className="font-serif text-4xl font-semibold">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6 space-y-3">
                <h3 className="font-semibold text-xl">Authenticity</h3>
                <p className="text-muted-foreground">
                  Every piece is authenticated and comes with a certificate of genuineness.
                </p>
              </Card>
              <Card className="p-6 space-y-3">
                <h3 className="font-semibold text-xl">Sustainability</h3>
                <p className="text-muted-foreground">
                  We partner with brands committed to ethical sourcing and sustainable practices.
                </p>
              </Card>
              <Card className="p-6 space-y-3">
                <h3 className="font-semibold text-xl">Excellence</h3>
                <p className="text-muted-foreground">
                  We maintain the highest standards in product selection and customer service.
                </p>
              </Card>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="font-serif text-4xl font-semibold">Our Mission</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              To make luxury accessible to discerning individuals who appreciate quality, craftsmanship, 
              and timeless design. We strive to create an exceptional shopping experience that reflects 
              the elegance of the products we offer.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
