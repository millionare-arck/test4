import { useState } from "react";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import handbagImage from '@assets/generated_images/Luxury_handbag_product_5cc5907a.png';
import jewelryImage from '@assets/generated_images/Gold_jewelry_collection_caec341b.png';
import sunglassesImage from '@assets/generated_images/Designer_sunglasses_product_120ebff3.png';

//todo: remove mock functionality
const allProducts = [
  {
    id: "1",
    name: "Signature Leather Handbag",
    price: 2499,
    imageUrl: handbagImage,
    category: "Accessories"
  },
  {
    id: "2",
    name: "Gold Jewelry Collection",
    price: 3799,
    imageUrl: jewelryImage,
    category: "Jewelry"
  },
  {
    id: "3",
    name: "Designer Sunglasses",
    price: 899,
    imageUrl: sunglassesImage,
    category: "Eyewear"
  },
  {
    id: "4",
    name: "Premium Leather Wallet",
    price: 599,
    imageUrl: handbagImage,
    category: "Accessories"
  },
  {
    id: "5",
    name: "Diamond Bracelet",
    price: 5299,
    imageUrl: jewelryImage,
    category: "Jewelry"
  },
  {
    id: "6",
    name: "Aviator Sunglasses",
    price: 799,
    imageUrl: sunglassesImage,
    category: "Eyewear"
  }
];

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("featured");

  const filteredProducts = selectedCategory === "all" 
    ? allProducts 
    : allProducts.filter(p => p.category === selectedCategory);

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === "price-low") return a.price - b.price;
    if (sortBy === "price-high") return b.price - a.price;
    return 0;
  });

  return (
    <div className="min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h1 className="font-serif text-5xl md:text-6xl font-semibold mb-4" data-testid="text-products-title">
            Our Collections
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Explore our curated selection of premium luxury goods
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-12">
          <div className="flex gap-2 flex-wrap">
            <Button 
              variant={selectedCategory === "all" ? "default" : "outline"}
              onClick={() => setSelectedCategory("all")}
              data-testid="button-filter-all"
            >
              All Products
            </Button>
            <Button 
              variant={selectedCategory === "Accessories" ? "default" : "outline"}
              onClick={() => setSelectedCategory("Accessories")}
              data-testid="button-filter-accessories"
            >
              Accessories
            </Button>
            <Button 
              variant={selectedCategory === "Jewelry" ? "default" : "outline"}
              onClick={() => setSelectedCategory("Jewelry")}
              data-testid="button-filter-jewelry"
            >
              Jewelry
            </Button>
            <Button 
              variant={selectedCategory === "Eyewear" ? "default" : "outline"}
              onClick={() => setSelectedCategory("Eyewear")}
              data-testid="button-filter-eyewear"
            >
              Eyewear
            </Button>
          </div>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full sm:w-48" data-testid="select-sort">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>

        {sortedProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-xl text-muted-foreground">No products found in this category</p>
          </div>
        )}
      </div>
    </div>
  );
}
