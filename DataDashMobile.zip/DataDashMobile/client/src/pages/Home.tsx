import Hero from "@/components/Hero";
import ProductGrid from "@/components/ProductGrid";
import ValueProposition from "@/components/ValueProposition";
import Testimonial from "@/components/Testimonial";
import heroImage from '@assets/generated_images/Luxury_hero_watch_image_ef817f30.png';
import handbagImage from '@assets/generated_images/Luxury_handbag_product_5cc5907a.png';
import jewelryImage from '@assets/generated_images/Gold_jewelry_collection_caec341b.png';
import sunglassesImage from '@assets/generated_images/Designer_sunglasses_product_120ebff3.png';
import testimonialImage from '@assets/generated_images/Customer_testimonial_portrait_e2c7be2d.png';

//todo: remove mock functionality
const featuredProducts = [
  {
    id: "1",
    name: "Signature Leather Handbag",
    price: 2499,
    imageUrl: handbagImage,
    category: "Accessories"
  },
  {
    id: "2",
    name: "Gold Jewelry Collection",
    price: 3799,
    imageUrl: jewelryImage,
    category: "Jewelry"
  },
  {
    id: "3",
    name: "Designer Sunglasses",
    price: 899,
    imageUrl: sunglassesImage,
    category: "Eyewear"
  }
];

export default function Home() {
  return (
    <div>
      <Hero
        title="Timeless Elegance"
        subtitle="Discover our curated collection of premium luxury goods"
        imageUrl={heroImage}
      />
      
      <ValueProposition />
      
      <ProductGrid products={featuredProducts} title="Featured Collection" />
      
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-center mb-12">
            What Our Clients Say
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <Testimonial
              quote="The craftsmanship and attention to detail is simply unparalleled. Every piece tells a story of elegance and refinement."
              author="Sophia Martinez"
              role="Fashion Director"
              imageUrl={testimonialImage}
            />
            <Testimonial
              quote="LuxeVault has become my go-to destination for exclusive luxury pieces. The service is impeccable and the quality exceptional."
              author="James Chen"
              role="Art Collector"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
